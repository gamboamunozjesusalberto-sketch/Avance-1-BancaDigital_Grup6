package com.banco.util;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * PATRON CREACIONAL: SINGLETON.
 * Garantiza una unica instancia (y una unica conexion) a la base de datos en todo el sistema.
 * Los datos de conexion se leen de application.properties (db.url, db.user, db.password).
 */
public final class ConexionBD {

    private static ConexionBD instancia;

    private final String url;
    private final String usuario;
    private final String clave;
    private Connection conexion;

    private ConexionBD() {
        Properties props = new Properties();
        try (InputStream in = ConexionBD.class.getResourceAsStream("/application.properties")) {
            if (in == null) {
                throw new IllegalStateException("No se encontro application.properties");
            }
            props.load(in);
        } catch (IOException e) {
            throw new DatabaseException("No se pudo leer application.properties", e);
        }
        this.url = props.getProperty("db.url");
        this.usuario = props.getProperty("db.user");
        this.clave = props.getProperty("db.password");
    }

    /** Punto de acceso global a la unica instancia. */
    public static synchronized ConexionBD getInstancia() {
        if (instancia == null) {
            instancia = new ConexionBD();
        }
        return instancia;
    }

    /** Devuelve la conexion unica; la reabre si se cerro o se perdio. */
    public synchronized Connection getConexion() {
        try {
            if (conexion == null || conexion.isClosed() || !conexion.isValid(2)) {
                conexion = DriverManager.getConnection(url, usuario, clave);
            }
            return conexion;
        } catch (SQLException e) {
            throw new DatabaseException("No se pudo conectar a la base de datos: " + e.getMessage(), e);
        }
    }
}
