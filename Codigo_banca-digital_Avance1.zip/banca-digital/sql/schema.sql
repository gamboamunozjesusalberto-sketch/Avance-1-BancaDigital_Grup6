-- Ejecutar dentro de la base de datos "banca_digital" (crearla antes en pgAdmin).
-- Los usuarios iniciales (admin, asesor, cajero, auditor) los crea la aplicacion al arrancar.

DROP TABLE IF EXISTS bitacora_acceso;
DROP TABLE IF EXISTS notificacion;   -- tabla de la version completa; aqui ya no se usa
DROP TABLE IF EXISTS solicitud_credito;
DROP TABLE IF EXISTS transaccion;
DROP TABLE IF EXISTS cuenta;
DROP TABLE IF EXISTS usuario;
DROP TABLE IF EXISTS cliente;
DROP TABLE IF EXISTS parametro;
DROP SEQUENCE IF EXISTS seq_numero_cuenta;

CREATE SEQUENCE seq_numero_cuenta START 1000000001;

CREATE TABLE parametro (
    clave        VARCHAR(40)  PRIMARY KEY,
    valor        VARCHAR(40)  NOT NULL,
    descripcion  VARCHAR(150) NOT NULL
);

INSERT INTO parametro (clave, valor, descripcion) VALUES
    ('LIMITE_OPERACION_DEFECTO', '5000', 'Limite por operacion (S/) que se asigna a cada cuenta nueva'),
    ('MONTO_MAXIMO_CREDITO', '100000', 'Monto maximo (S/) que un cliente puede pedir en una solicitud de credito');

CREATE TABLE cliente (
    id        SERIAL PRIMARY KEY,
    nombre    VARCHAR(100) NOT NULL,
    dni       VARCHAR(8)   NOT NULL UNIQUE,
    correo    VARCHAR(100) NOT NULL,
    telefono  VARCHAR(9)
);

CREATE TABLE usuario (
    id             SERIAL PRIMARY KEY,
    username       VARCHAR(30)  NOT NULL UNIQUE,
    password_hash  VARCHAR(100) NOT NULL,
    nombre         VARCHAR(100) NOT NULL,
    rol            VARCHAR(20)  NOT NULL CHECK (rol IN ('ADMINISTRADOR', 'CLIENTE', 'ASESOR', 'CAJERO', 'AUDITOR')),
    activo         BOOLEAN      NOT NULL DEFAULT TRUE,
    cliente_id     INT UNIQUE REFERENCES cliente(id)
);

CREATE TABLE cuenta (
    id                SERIAL PRIMARY KEY,
    numero            VARCHAR(20)   NOT NULL UNIQUE,
    tipo              VARCHAR(10)   NOT NULL CHECK (tipo IN ('AHORROS', 'CORRIENTE')),
    saldo             NUMERIC(14,2) NOT NULL DEFAULT 0,
    limite_operacion  NUMERIC(14,2) NOT NULL CHECK (limite_operacion > 0),
    cliente_id        INT           NOT NULL REFERENCES cliente(id),
    fecha_apertura    TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE transaccion (
    id                SERIAL PRIMARY KEY,
    cuenta_id         INT           NOT NULL REFERENCES cuenta(id),
    tipo              VARCHAR(25)   NOT NULL CHECK (tipo IN
                      ('DEPOSITO', 'RETIRO', 'TRANSFERENCIA_ENVIADA', 'TRANSFERENCIA_RECIBIDA', 'PAGO_SERVICIO')),
    monto             NUMERIC(14,2) NOT NULL CHECK (monto > 0),
    saldo_resultante  NUMERIC(14,2) NOT NULL,
    fecha             TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    descripcion       VARCHAR(150)
);

CREATE TABLE solicitud_credito (
    id                SERIAL PRIMARY KEY,
    cliente_id        INT           NOT NULL REFERENCES cliente(id),
    monto             NUMERIC(14,2) NOT NULL CHECK (monto > 0),
    plazo_meses       INT           NOT NULL CHECK (plazo_meses > 0),
    motivo            VARCHAR(200)  NOT NULL,
    estado            VARCHAR(12)   NOT NULL DEFAULT 'PENDIENTE' CHECK (estado IN ('PENDIENTE', 'APROBADA', 'RECHAZADA')),
    observaciones     VARCHAR(250),
    asesor_id         INT REFERENCES usuario(id),
    fecha_solicitud   TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    fecha_resolucion  TIMESTAMP
);

CREATE TABLE bitacora_acceso (
    id        SERIAL PRIMARY KEY,
    username  VARCHAR(30)  NOT NULL,
    evento    VARCHAR(20)  NOT NULL,
    detalle   VARCHAR(150),
    fecha     TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP
);
