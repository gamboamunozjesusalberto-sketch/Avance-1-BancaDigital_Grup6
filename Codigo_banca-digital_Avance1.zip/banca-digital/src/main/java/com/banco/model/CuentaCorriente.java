package com.banco.model;

import java.math.BigDecimal;

/** Cuenta corriente: permite un sobregiro de hasta S/ 500. */
public class CuentaCorriente extends Cuenta {
    @Override
    public TipoCuenta getTipo() { return TipoCuenta.CORRIENTE; }

    @Override
    public BigDecimal getSobregiroPermitido() { return new BigDecimal("500.00"); }
}
