package com.banco.model;

/** Estados posibles de una solicitud de credito (se guardan como texto en la base de datos). */
public enum EstadoSolicitud {
    PENDIENTE,
    APROBADA,
    RECHAZADA;

    /** Nombre que se muestra en las pantallas. */
    public String getNombre() {
        return name();
    }
}
