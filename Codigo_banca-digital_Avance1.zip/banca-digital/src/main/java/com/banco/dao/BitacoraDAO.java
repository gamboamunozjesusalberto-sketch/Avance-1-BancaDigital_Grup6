package com.banco.dao;

import com.banco.model.RegistroAcceso;

import java.util.List;

public interface BitacoraDAO {
    void registrar(String username, String evento, String detalle);
    List<RegistroAcceso> listarRecientes(int limite);
}
