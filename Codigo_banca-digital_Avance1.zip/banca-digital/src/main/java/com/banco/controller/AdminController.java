package com.banco.controller;

import com.banco.model.Rol;
import com.banco.service.ParametroService;
import com.banco.service.UsuarioService;
import com.banco.util.DatabaseException;
import com.banco.util.NegocioException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.security.Principal;
import java.util.List;

/**
 * GRASP CONTROLADOR (actor ADMINISTRADOR): gestion de usuarios y roles, y configuracion de parametros.
 */
@Controller
@RequestMapping("/admin")
public class AdminController {

    private static final List<Rol> ROLES_PERSONAL = List.of(Rol.ADMINISTRADOR, Rol.ASESOR, Rol.CAJERO, Rol.AUDITOR);

    private final UsuarioService usuarioService;
    private final ParametroService parametroService;

    public AdminController(UsuarioService usuarioService, ParametroService parametroService) {
        this.usuarioService = usuarioService;
        this.parametroService = parametroService;
    }

    @GetMapping("")
    public String inicio() {
        return "redirect:/admin/usuarios";
    }

    // ----------------------------- Usuarios y roles -----------------------------

    @GetMapping("/usuarios")
    public String usuarios(Model model) {
        cargarUsuarios(model);
        return "admin/usuarios";
    }

    @PostMapping("/usuarios")
    public String crearUsuario(@RequestParam String username, @RequestParam String password,
                               @RequestParam String nombre, @RequestParam Rol rol,
                               Model model, RedirectAttributes flash) {
        try {
            usuarioService.crearPersonal(username, password, nombre, rol);
            flash.addFlashAttribute("ok", "Usuario " + username + " creado correctamente");
            return "redirect:/admin/usuarios";
        } catch (NegocioException | DatabaseException e) {
            model.addAttribute("error", e.getMessage());
            cargarUsuarios(model);
            return "admin/usuarios";
        }
    }

    @PostMapping("/usuarios/{id}/estado")
    public String cambiarEstado(@PathVariable int id, @RequestParam boolean activo,
                                Principal principal, RedirectAttributes flash) {
        try {
            usuarioService.cambiarEstado(id, activo, principal.getName());
            flash.addFlashAttribute("ok", activo ? "Usuario activado" : "Usuario desactivado");
        } catch (NegocioException | DatabaseException e) {
            flash.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/admin/usuarios";
    }

    @PostMapping("/usuarios/{id}/rol")
    public String cambiarRol(@PathVariable int id, @RequestParam Rol rol,
                             Principal principal, RedirectAttributes flash) {
        try {
            usuarioService.cambiarRol(id, rol, principal.getName());
            flash.addFlashAttribute("ok", "Rol actualizado");
        } catch (NegocioException | DatabaseException e) {
            flash.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/admin/usuarios";
    }

    // ----------------------------- Parametros -----------------------------

    @GetMapping("/parametros")
    public String parametros(Model model) {
        model.addAttribute("parametros", parametroService.listar());
        return "admin/parametros";
    }

    @PostMapping("/parametros")
    public String guardarParametro(@RequestParam String clave, @RequestParam String valor, RedirectAttributes flash) {
        try {
            parametroService.actualizar(clave, valor);
            flash.addFlashAttribute("ok", "Parametro actualizado");
        } catch (NegocioException | DatabaseException e) {
            flash.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/admin/parametros";
    }

    private void cargarUsuarios(Model model) {
        model.addAttribute("usuarios", usuarioService.listar());
        model.addAttribute("roles", ROLES_PERSONAL);
    }
}
