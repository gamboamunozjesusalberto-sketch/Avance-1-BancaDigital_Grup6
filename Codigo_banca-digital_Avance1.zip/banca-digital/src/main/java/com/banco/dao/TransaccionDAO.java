package com.banco.dao;

import com.banco.model.TipoTransaccion;
import com.banco.model.Transaccion;

import java.util.List;
import java.util.Optional;

public interface TransaccionDAO {
    void insertar(Transaccion transaccion);
    List<Transaccion> listarPorCuenta(int cuentaId);
    Optional<Transaccion> buscarPorId(int id);
    /** Ultimas 300 transacciones; si tipo es null, de todos los tipos. */
    List<Transaccion> listarTodas(TipoTransaccion tipo);
}
