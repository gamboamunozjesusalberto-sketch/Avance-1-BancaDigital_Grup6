package com.banco.service;

import com.banco.dao.ClienteDAO;
import com.banco.dao.factory.DAOFactory;
import com.banco.model.Cliente;
import com.banco.model.Rol;
import com.banco.util.NegocioException;
import com.banco.util.TransaccionJdbc;
import com.banco.util.Validaciones;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Capa de LOGICA DE NEGOCIO para clientes: validacion de datos y control de duplicados.
 * Obtiene su DAO desde la fabrica (Factory) y solo conoce la interfaz (SOLID - D).
 */
@Service
public class ClienteService {

    private final ClienteDAO clienteDAO = DAOFactory.getClienteDAO();
    private final UsuarioService usuarioService;

    public ClienteService(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    /**
     * El cajero registra al cliente y se crea su usuario de acceso (usuario = DNI).
     * Ambas cosas van en una sola TRANSACCION: si falla el usuario, tampoco se guarda el cliente.
     */
    public Cliente registrarConAcceso(Cliente cliente, String password) {
        return TransaccionJdbc.ejecutar(() -> {
            registrar(cliente);
            usuarioService.crear(cliente.getDni(), password, cliente.getNombre(), Rol.CLIENTE, cliente.getId());
            return cliente;
        });
    }

    public void registrar(Cliente c) {
        if (Validaciones.vacio(c.getNombre())) {
            throw new NegocioException("El nombre es obligatorio");
        }
        if (!Validaciones.dniValido(c.getDni())) {
            throw new NegocioException("El DNI debe tener exactamente 8 digitos");
        }
        if (!Validaciones.correoValido(c.getCorreo())) {
            throw new NegocioException("El correo no tiene un formato valido");
        }
        if (!Validaciones.telefonoValido(c.getTelefono())) {
            throw new NegocioException("El telefono debe tener 9 digitos");
        }
        if (clienteDAO.existePorDni(c.getDni())) {
            throw new NegocioException("Ya existe un cliente registrado con ese DNI");
        }
        c.setNombre(c.getNombre().trim());
        if (Validaciones.vacio(c.getTelefono())) {
            c.setTelefono(null);
        }
        clienteDAO.insertar(c);
    }

    public List<Cliente> listar() {
        return clienteDAO.listar();
    }

    public Cliente buscar(int id) {
        return clienteDAO.buscarPorId(id).orElseThrow(() -> new NegocioException("El cliente no existe"));
    }
}
