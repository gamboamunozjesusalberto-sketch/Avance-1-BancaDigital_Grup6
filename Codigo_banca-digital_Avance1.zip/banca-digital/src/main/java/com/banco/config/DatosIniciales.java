package com.banco.config;

import com.banco.dao.factory.DAOFactory;
import com.banco.model.Rol;
import com.banco.service.UsuarioService;
import com.banco.util.DatabaseException;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

/**
 * Al arrancar, si todavia no existe ningun usuario, crea uno por cada rol del personal del banco.
 * Las contrasenas se guardan cifradas con BCrypt. CAMBIALAS desde el panel del administrador
 * (o en el codigo) antes de mostrar el sistema a otras personas.
 */
@Component
public class DatosIniciales implements CommandLineRunner {

    private final UsuarioService usuarioService;

    public DatosIniciales(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    @Override
    public void run(String... args) {
        try {
            if (DAOFactory.getUsuarioDAO().contar() > 0) {
                return;
            }
            usuarioService.crearPersonal("admin", "admin123", "Administrador del sistema", Rol.ADMINISTRADOR);
            usuarioService.crearPersonal("asesor", "asesor123", "Asesor de credito", Rol.ASESOR);
            usuarioService.crearPersonal("cajero", "cajero123", "Cajero de ventanilla", Rol.CAJERO);
            usuarioService.crearPersonal("auditor", "auditor123", "Auditor interno", Rol.AUDITOR);
            System.out.println(">>> Usuarios iniciales creados: admin, asesor, cajero y auditor (ver README para las claves).");
        } catch (DatabaseException e) {
            System.err.println(">>> No se pudieron crear los usuarios iniciales. Revisa que PostgreSQL este encendido, "
                    + "que exista la base banca_digital con las tablas de sql/schema.sql y la clave en application.properties.");
            System.err.println(">>> Detalle: " + e.getMessage());
        }
    }
}
