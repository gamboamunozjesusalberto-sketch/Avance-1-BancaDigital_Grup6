package com.banco.service;

import com.banco.dao.ClienteDAO;
import com.banco.dao.CuentaDAO;
import com.banco.dao.TransaccionDAO;
import com.banco.dao.factory.DAOFactory;
import com.banco.model.Cuenta;
import com.banco.model.TipoCuenta;
import com.banco.model.TipoTransaccion;
import com.banco.model.Transaccion;
import com.banco.patterns.adapter.PasarelaPagoServicios;
import com.banco.util.NegocioException;
import com.banco.util.TransaccionJdbc;
import com.banco.util.Validaciones;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;

/**
 * Capa de LOGICA DE NEGOCIO para cuentas y operaciones.
 * Usa TRANSACCIONES JDBC (TransaccionJdbc): actualizar saldos y registrar movimientos ocurren
 * juntos (commit) o no ocurren (rollback).
 * Los DAO se obtienen de la fabrica (Factory) y el pago de servicios pasa por un adaptador (Adapter).
 */
@Service
public class CuentaService {

    private static final int LARGO_MAXIMO_DESCRIPCION = 150;

    private final CuentaDAO cuentaDAO = DAOFactory.getCuentaDAO();
    private final ClienteDAO clienteDAO = DAOFactory.getClienteDAO();
    private final TransaccionDAO transaccionDAO = DAOFactory.getTransaccionDAO();
    private final ParametroService parametroService;
    private final PasarelaPagoServicios pasarelaPagos;

    /** SOLID (D): recibe la interfaz PasarelaPagoServicios, no la clase concreta del adaptador. */
    public CuentaService(ParametroService parametroService, PasarelaPagoServicios pasarelaPagos) {
        this.parametroService = parametroService;
        this.pasarelaPagos = pasarelaPagos;
    }

    // ------------------------------------------------------------------ cuentas (cajero)

    public Cuenta abrirCuenta(int clienteId, TipoCuenta tipo, BigDecimal depositoInicial) {
        BigDecimal inicial = depositoInicial == null ? BigDecimal.ZERO : depositoInicial;
        if (inicial.signum() < 0 || inicial.scale() > 2) {
            throw new NegocioException("El deposito inicial no es valido");
        }
        if (tipo == null) {
            throw new NegocioException("Debes elegir el tipo de cuenta");
        }
        clienteDAO.buscarPorId(clienteId)
                .orElseThrow(() -> new NegocioException("El cliente seleccionado no existe"));
        BigDecimal limite = parametroService.obtenerDecimal(ParametroService.LIMITE_OPERACION_DEFECTO,
                new BigDecimal("5000"));

        return TransaccionJdbc.ejecutar(() -> {
            // PATRON FACTORY (metodo de fabrica): Cuenta.crear devuelve CuentaAhorros o CuentaCorriente
            Cuenta nueva = Cuenta.crear(tipo);
            nueva.setNumero(cuentaDAO.siguienteNumero());
            nueva.setClienteId(clienteId);
            nueva.setLimiteOperacion(limite);
            if (inicial.signum() > 0) {
                nueva.depositar(inicial);
            }
            cuentaDAO.insertar(nueva);
            if (inicial.signum() > 0) {
                registrarMovimiento(nueva, TipoTransaccion.DEPOSITO, inicial, "Deposito inicial");
            }
            return nueva;
        });
    }

    public List<Cuenta> listar() {
        return cuentaDAO.listar();
    }

    public List<Cuenta> listarPorCliente(int clienteId) {
        return cuentaDAO.listarPorCliente(clienteId);
    }

    public Cuenta buscar(int cuentaId) {
        return cuentaDAO.buscarPorId(cuentaId).orElseThrow(() -> new NegocioException("La cuenta no existe"));
    }

    /** Busca la cuenta y comprueba que pertenezca al cliente (un cliente solo ve lo suyo). */
    public Cuenta buscarDeCliente(int cuentaId, int clienteId) {
        Cuenta cuenta = buscar(cuentaId);
        verificarPropietario(cuenta, clienteId);
        return cuenta;
    }

    public List<Transaccion> historial(int cuentaId) {
        return transaccionDAO.listarPorCuenta(cuentaId);
    }

    public Transaccion buscarTransaccion(int transaccionId) {
        return transaccionDAO.buscarPorId(transaccionId)
                .orElseThrow(() -> new NegocioException("El comprobante no existe"));
    }

    // ------------------------------------------------------------------ operaciones de caja (cajero)

    /** Deposito en ventanilla. Devuelve la transaccion registrada (para emitir el comprobante). */
    public Transaccion depositar(int cuentaId, BigDecimal monto, String descripcion) {
        return operarEnCaja(cuentaId, TipoTransaccion.DEPOSITO, monto, descripcion);
    }

    /** Retiro en ventanilla. */
    public Transaccion retirar(int cuentaId, BigDecimal monto, String descripcion) {
        return operarEnCaja(cuentaId, TipoTransaccion.RETIRO, monto, descripcion);
    }

    // ------------------------------------------------------------------ operaciones del cliente (canal digital)

    public Transaccion transferir(int clienteId, int cuentaOrigenId, String numeroDestino,
                                  BigDecimal monto, String descripcion) {
        if (Validaciones.vacio(numeroDestino)) {
            throw new NegocioException("Indica el numero de la cuenta destino");
        }
        return TransaccionJdbc.ejecutar(() -> {
            Cuenta origen = buscarDeCliente(cuentaOrigenId, clienteId);
            Cuenta destino = cuentaDAO.buscarPorNumero(numeroDestino.trim())
                    .orElseThrow(() -> new NegocioException("La cuenta destino no existe"));
            if (origen.getId() == destino.getId()) {
                throw new NegocioException("La cuenta destino debe ser distinta de la cuenta origen");
            }
            // GRASP Experto: cada cuenta valida y calcula su propio saldo
            origen.validarLimiteOperacion(monto);
            origen.retirar(monto);
            destino.depositar(monto);
            cuentaDAO.actualizarSaldo(origen.getId(), origen.getSaldo());
            cuentaDAO.actualizarSaldo(destino.getId(), destino.getSaldo());

            String nota = Validaciones.vacio(descripcion) ? "" : " - " + descripcion.trim();
            Transaccion salida = registrarMovimiento(origen, TipoTransaccion.TRANSFERENCIA_ENVIADA, monto,
                    "Transferencia a " + destino.getNumero() + " (" + destino.getClienteNombre() + ")" + nota);
            registrarMovimiento(destino, TipoTransaccion.TRANSFERENCIA_RECIBIDA, monto,
                    "Transferencia de " + origen.getNumero() + " (" + origen.getClienteNombre() + ")" + nota);
            return salida;
        });
    }

    /**
     * Pago de servicios. El cobro lo hace la empresa externa a traves del ADAPTER: si la empresa
     * rechaza el pago se lanza una excepcion y la transaccion hace rollback (el saldo no cambia).
     */
    public Transaccion pagarServicio(int clienteId, int cuentaId, String servicio, String referencia, BigDecimal monto) {
        if (Validaciones.vacio(servicio) || Validaciones.vacio(referencia)) {
            throw new NegocioException("Indica el servicio y el codigo de suministro");
        }
        return TransaccionJdbc.ejecutar(() -> {
            Cuenta cuenta = buscarDeCliente(cuentaId, clienteId);
            cuenta.validarLimiteOperacion(monto);
            cuenta.retirar(monto);
            String codigoOperacion = pasarelaPagos.pagar(servicio, referencia.trim(), monto);
            cuentaDAO.actualizarSaldo(cuenta.getId(), cuenta.getSaldo());
            String detalle = "Pago de " + servicio + " (suministro " + referencia.trim() + ", operacion "
                    + codigoOperacion + ")";
            return registrarMovimiento(cuenta, TipoTransaccion.PAGO_SERVICIO, monto, detalle);
        });
    }

    // ------------------------------------------------------------------ interno

    private Transaccion operarEnCaja(int cuentaId, TipoTransaccion tipo, BigDecimal monto, String descripcion) {
        return TransaccionJdbc.ejecutar(() -> {
            Cuenta cuenta = buscar(cuentaId);
            // GRASP Experto: la propia cuenta valida y calcula el nuevo saldo
            if (tipo == TipoTransaccion.DEPOSITO) {
                cuenta.depositar(monto);
            } else {
                cuenta.retirar(monto);
            }
            cuentaDAO.actualizarSaldo(cuenta.getId(), cuenta.getSaldo());
            return registrarMovimiento(cuenta, tipo, monto, descripcion);
        });
    }

    private Transaccion registrarMovimiento(Cuenta cuenta, TipoTransaccion tipo, BigDecimal monto, String descripcion) {
        String texto = Validaciones.vacio(descripcion) ? null : descripcion.trim();
        if (texto != null && texto.length() > LARGO_MAXIMO_DESCRIPCION) {
            texto = texto.substring(0, LARGO_MAXIMO_DESCRIPCION);
        }
        Transaccion t = new Transaccion();
        t.setCuentaId(cuenta.getId());
        t.setTipo(tipo);
        t.setMonto(monto);
        t.setSaldoResultante(cuenta.getSaldo());
        t.setDescripcion(texto);
        transaccionDAO.insertar(t);
        return t;
    }

    private void verificarPropietario(Cuenta cuenta, int clienteId) {
        if (cuenta.getClienteId() != clienteId) {
            throw new NegocioException("La cuenta no pertenece al cliente");
        }
    }
}
