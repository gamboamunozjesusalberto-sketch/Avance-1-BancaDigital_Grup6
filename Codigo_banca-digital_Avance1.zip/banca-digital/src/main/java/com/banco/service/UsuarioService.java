package com.banco.service;

import com.banco.dao.UsuarioDAO;
import com.banco.dao.factory.DAOFactory;
import com.banco.model.Rol;
import com.banco.model.Usuario;
import com.banco.util.NegocioException;
import com.banco.util.Validaciones;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Gestion de usuarios y roles. La contrasena se guarda siempre cifrada con BCrypt
 * (PasswordEncoder de Spring Security); nunca se guarda el texto original.
 */
@Service
public class UsuarioService {

    private final UsuarioDAO usuarioDAO = DAOFactory.getUsuarioDAO();
    private final PasswordEncoder passwordEncoder;

    public UsuarioService(PasswordEncoder passwordEncoder) {
        this.passwordEncoder = passwordEncoder;
    }

    public Usuario crear(String username, String password, String nombre, Rol rol, Integer clienteId) {
        if (!Validaciones.usernameValido(username)) {
            throw new NegocioException("El usuario debe tener entre 3 y 30 caracteres (letras, numeros, punto, guion)");
        }
        if (!Validaciones.passwordValida(password)) {
            throw new NegocioException("La contrasena debe tener al menos 6 caracteres");
        }
        if (Validaciones.vacio(nombre)) {
            throw new NegocioException("El nombre es obligatorio");
        }
        if (rol == null) {
            throw new NegocioException("Debes elegir un rol");
        }
        if (usuarioDAO.existeUsername(username)) {
            throw new NegocioException("Ya existe un usuario con ese nombre de usuario");
        }
        Usuario u = new Usuario();
        u.setUsername(username.trim());
        u.setPasswordHash(passwordEncoder.encode(password));
        u.setNombre(nombre.trim());
        u.setRol(rol);
        u.setClienteId(clienteId);
        usuarioDAO.insertar(u);
        return u;
    }

    /** El administrador solo crea personal del banco; los clientes se registran por otra via. */
    public Usuario crearPersonal(String username, String password, String nombre, Rol rol) {
        if (rol == Rol.CLIENTE) {
            throw new NegocioException("Los clientes se registran desde el modulo de clientes");
        }
        return crear(username, password, nombre, rol, null);
    }

    public List<Usuario> listar() {
        return usuarioDAO.listar();
    }

    public void cambiarEstado(int id, boolean activo, String usernameActual) {
        Usuario objetivo = usuarioDAO.buscarPorId(id)
                .orElseThrow(() -> new NegocioException("El usuario no existe"));
        if (objetivo.getUsername().equals(usernameActual)) {
            throw new NegocioException("No puedes desactivar tu propio usuario");
        }
        usuarioDAO.cambiarEstado(id, activo);
    }

    public void cambiarRol(int id, Rol nuevoRol, String usernameActual) {
        Usuario objetivo = usuarioDAO.buscarPorId(id)
                .orElseThrow(() -> new NegocioException("El usuario no existe"));
        if (objetivo.getUsername().equals(usernameActual)) {
            throw new NegocioException("No puedes cambiar tu propio rol");
        }
        if (objetivo.getRol() == Rol.CLIENTE || nuevoRol == Rol.CLIENTE) {
            throw new NegocioException("Los roles de clientes no se modifican desde aqui");
        }
        usuarioDAO.cambiarRol(id, nuevoRol);
    }

    public Usuario buscarPorUsername(String username) {
        return usuarioDAO.buscarPorUsername(username)
                .orElseThrow(() -> new NegocioException("El usuario no existe"));
    }

    /** Devuelve el id del cliente asociado a un usuario con rol CLIENTE. */
    public int clienteIdDe(String username) {
        Integer clienteId = buscarPorUsername(username).getClienteId();
        if (clienteId == null) {
            throw new NegocioException("Este usuario no esta asociado a un cliente");
        }
        return clienteId;
    }
}
