package com.banco.model;

public enum TipoTransaccion {
    DEPOSITO, RETIRO, TRANSFERENCIA_ENVIADA, TRANSFERENCIA_RECIBIDA, PAGO_SERVICIO
}
