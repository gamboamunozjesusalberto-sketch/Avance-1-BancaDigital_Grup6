package com.banco.service;

import com.banco.dao.BitacoraDAO;
import com.banco.dao.TransaccionDAO;
import com.banco.dao.factory.DAOFactory;
import com.banco.model.RegistroAcceso;
import com.banco.model.TipoTransaccion;
import com.banco.model.Transaccion;
import org.springframework.stereotype.Service;

import java.util.List;

/** Consultas del auditor: revisar transacciones y consultar la bitacora de accesos. */
@Service
public class AuditoriaService {

    private static final int REGISTROS_BITACORA = 200;

    private final BitacoraDAO bitacoraDAO = DAOFactory.getBitacoraDAO();
    private final TransaccionDAO transaccionDAO = DAOFactory.getTransaccionDAO();

    /** Registra un ingreso, salida o intento fallido. Un fallo de la bitacora no debe impedir el acceso. */
    public void registrarAcceso(String username, String evento, String detalle) {
        try {
            bitacoraDAO.registrar(username, evento, detalle);
        } catch (RuntimeException ignorada) {
            // la bitacora es de apoyo; no debe bloquear el login
        }
    }

    public List<RegistroAcceso> bitacora() {
        return bitacoraDAO.listarRecientes(REGISTROS_BITACORA);
    }

    /** Ultimas transacciones; si tipo es null, de todos los tipos. */
    public List<Transaccion> transacciones(TipoTransaccion tipo) {
        return transaccionDAO.listarTodas(tipo);
    }
}
