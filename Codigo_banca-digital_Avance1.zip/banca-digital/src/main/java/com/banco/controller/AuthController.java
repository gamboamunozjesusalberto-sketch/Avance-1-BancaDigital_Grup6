package com.banco.controller;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/** Entrada al sistema: login y redireccion segun el rol. */
@Controller
public class AuthController {

    /** Despues de ingresar, cada actor va a su propio panel. */
    @GetMapping("/")
    public String inicio(Authentication authentication) {
        for (GrantedAuthority autoridad : authentication.getAuthorities()) {
            switch (autoridad.getAuthority()) {
                case "ROLE_ADMINISTRADOR": return "redirect:/admin";
                case "ROLE_CLIENTE": return "redirect:/cliente";
                case "ROLE_ASESOR": return "redirect:/asesor";
                case "ROLE_CAJERO": return "redirect:/cajero";
                case "ROLE_AUDITOR": return "redirect:/auditor";
                default: break;
            }
        }
        return "redirect:/login";
    }

    @GetMapping("/login")
    public String login() {
        return "login";
    }

    @GetMapping("/acceso-denegado")
    public String accesoDenegado() {
        return "acceso-denegado";
    }
}
