package com.banco.model;

import com.banco.util.NegocioException;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Solicitud de credito de un cliente.
 * GRASP EXPERTO: la solicitud conoce su estado, por eso ella misma decide si puede aprobarse o rechazarse.
 */
public class SolicitudCredito {
    private int id;
    private int clienteId;
    private String clienteNombre;
    private BigDecimal monto;
    private int plazoMeses;
    private String motivo;
    private EstadoSolicitud estado = EstadoSolicitud.PENDIENTE;
    private String observaciones;
    private Integer asesorId;
    private LocalDateTime fechaSolicitud;
    private LocalDateTime fechaResolucion;

    public void aprobar() {
        verificarPendiente();
        estado = EstadoSolicitud.APROBADA;
    }

    public void rechazar() {
        verificarPendiente();
        estado = EstadoSolicitud.RECHAZADA;
    }

    public boolean isPendiente() { return estado == EstadoSolicitud.PENDIENTE; }

    /** Solo una solicitud pendiente puede cambiar de estado. */
    private void verificarPendiente() {
        if (!isPendiente()) {
            throw new NegocioException("La solicitud ya fue " + estado.getNombre().toLowerCase() + " y no admite cambios");
        }
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getClienteId() { return clienteId; }
    public void setClienteId(int clienteId) { this.clienteId = clienteId; }
    public String getClienteNombre() { return clienteNombre; }
    public void setClienteNombre(String clienteNombre) { this.clienteNombre = clienteNombre; }
    public BigDecimal getMonto() { return monto; }
    public void setMonto(BigDecimal monto) { this.monto = monto; }
    public int getPlazoMeses() { return plazoMeses; }
    public void setPlazoMeses(int plazoMeses) { this.plazoMeses = plazoMeses; }
    public String getMotivo() { return motivo; }
    public void setMotivo(String motivo) { this.motivo = motivo; }
    public EstadoSolicitud getEstado() { return estado; }
    public void setEstado(EstadoSolicitud estado) { this.estado = estado; }
    public String getObservaciones() { return observaciones; }
    public void setObservaciones(String observaciones) { this.observaciones = observaciones; }
    public Integer getAsesorId() { return asesorId; }
    public void setAsesorId(Integer asesorId) { this.asesorId = asesorId; }
    public LocalDateTime getFechaSolicitud() { return fechaSolicitud; }
    public void setFechaSolicitud(LocalDateTime fechaSolicitud) { this.fechaSolicitud = fechaSolicitud; }
    public LocalDateTime getFechaResolucion() { return fechaResolucion; }
    public void setFechaResolucion(LocalDateTime fechaResolucion) { this.fechaResolucion = fechaResolucion; }
}
