package com.banco.service;

import com.banco.dao.ParametroDAO;
import com.banco.dao.factory.DAOFactory;
import com.banco.model.Cuenta;
import com.banco.model.Parametro;
import com.banco.util.NegocioException;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;

/** Lee y modifica los parametros de configuracion (los numeros que antes estarian "magicos" en el codigo). */
@Service
public class ParametroService {

    public static final String LIMITE_OPERACION_DEFECTO = "LIMITE_OPERACION_DEFECTO";
    public static final String MONTO_MAXIMO_CREDITO = "MONTO_MAXIMO_CREDITO";

    private final ParametroDAO parametroDAO = DAOFactory.getParametroDAO();

    public BigDecimal obtenerDecimal(String clave, BigDecimal porDefecto) {
        return parametroDAO.obtenerValor(clave).map(valor -> {
            try {
                return new BigDecimal(valor);
            } catch (NumberFormatException e) {
                return porDefecto;
            }
        }).orElse(porDefecto);
    }

    public List<Parametro> listar() {
        return parametroDAO.listar();
    }

    public void actualizar(String clave, String valor) {
        boolean existe = parametroDAO.listar().stream().anyMatch(p -> p.getClave().equals(clave));
        if (!existe) {
            throw new NegocioException("El parametro no existe");
        }
        BigDecimal numero;
        try {
            numero = new BigDecimal(valor == null ? "" : valor.trim());
        } catch (NumberFormatException e) {
            throw new NegocioException("El valor debe ser un numero");
        }
        if (numero.signum() <= 0 || numero.scale() > 2) {
            throw new NegocioException("El valor debe ser mayor a 0 y con maximo 2 decimales");
        }
        if (LIMITE_OPERACION_DEFECTO.equals(clave) && numero.compareTo(Cuenta.LIMITE_MAXIMO_CONFIGURABLE) > 0) {
            throw new NegocioException("El limite por defecto no puede superar S/ " + Cuenta.LIMITE_MAXIMO_CONFIGURABLE);
        }
        parametroDAO.actualizar(clave, numero.toPlainString());
    }
}
