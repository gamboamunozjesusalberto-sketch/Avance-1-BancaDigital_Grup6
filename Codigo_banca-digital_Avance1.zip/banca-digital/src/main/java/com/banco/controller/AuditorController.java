package com.banco.controller;

import com.banco.model.TipoTransaccion;
import com.banco.service.AuditoriaService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;


/**
 * GRASP CONTROLADOR (actor AUDITOR): revisar transacciones y consultar la bitacora de accesos.
 */
@Controller
@RequestMapping("/auditor")
public class AuditorController {

    private final AuditoriaService auditoriaService;

    public AuditorController(AuditoriaService auditoriaService) {
        this.auditoriaService = auditoriaService;
    }

    @GetMapping("")
    public String inicio() {
        return "redirect:/auditor/transacciones";
    }

    @GetMapping("/transacciones")
    public String transacciones(@RequestParam(required = false) TipoTransaccion tipo, Model model) {
        model.addAttribute("transacciones", auditoriaService.transacciones(tipo));
        model.addAttribute("tipos", TipoTransaccion.values());
        model.addAttribute("tipoSeleccionado", tipo);
        return "auditor/transacciones";
    }

    @GetMapping("/bitacora")
    public String bitacora(Model model) {
        model.addAttribute("registros", auditoriaService.bitacora());
        return "auditor/bitacora";
    }
}
